﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management
{
    public partial class add_student : Form
    {
        public add_student()
        {
            InitializeComponent();
        }

        private void btn_quit_Click(object sender, EventArgs e)
        {
            main_menu mm = new main_menu();
            this.Hide();
            mm.Show();

        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Home\Documents\icon_college.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "Insert into students (Id, firstname, lastname, departments, gender, address, phone, dob, email) values (@Id, @firstname, @lastname, @departments, @gender, @address, @phone, @dob, @email)"; 
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@Id", txt_Id.Text);
            cmd.Parameters.AddWithValue("@firstname", txt_firstname.Text);
            cmd.Parameters.AddWithValue("@lastname", txt_lastname.Text);
            cmd.Parameters.AddWithValue("@departments", cb_department.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@gender", cb_gender.SelectedItem.ToString());
            cmd.Parameters.AddWithValue("@address", txt_address.Text);
            cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
            cmd.Parameters.AddWithValue("@dob", dtp_dob.Value.ToString());
            cmd.Parameters.AddWithValue("@email", txt_email.Text);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show("New Details Implemented Sucssesfully");
                main_menu mm = new main_menu();
                this.Hide();
                mm.Show();

            }
            catch(SqlException ex)
            {
                MessageBox.Show("An Error occured while implementing into Student Database" +ex.ToString());

            }
            finally
            {
                con.Close();
              

            }

        }
     
    }
}
