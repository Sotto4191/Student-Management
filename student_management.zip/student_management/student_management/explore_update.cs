﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management
{
    public partial class explore_update : Form
    {
        public explore_update()
        {
            InitializeComponent();
        }

        private void groupbox1_Enter(object sender, EventArgs e)
        {

        }

        private void explore_update_Load(object sender, EventArgs e)
        {
            btn_update.Enabled = false;
            groupbox1.Enabled = false;

        }

        private void btn_quit_Click(object sender, EventArgs e)
        {
            main_menu mm = new main_menu();
            this.Hide();
            mm.Show();

        }

        private void btn_explore_Click(object sender, EventArgs e)
        {
            if (txt_Id.Text == "")
                MessageBox.Show("You are required yo enter an ID");

            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Home\Documents\icon_college.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "select * from students where Id = '" + txt_Id.Text + "' ";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)

                {
                    btn_update.Enabled = true;
                    groupbox1.Enabled = true;                   
                    txt_firstname.Text = dt.Rows[0][1].ToString();
                    txt_lastname.Text = dt.Rows[0][2].ToString();
                    txt_department.Text = dt.Rows[0][3].ToString();
                    txt_gender.Text = dt.Rows[0][4].ToString();
                    txt_address.Text = dt.Rows[0][5].ToString();
                    txt_phone.Text = dt.Rows[0][6].ToString();
                    txt_dob.Text = dt.Rows[0][7].ToString();
                    txt_email.Text = dt.Rows[0][8].ToString();

                }


                else
                    MessageBox.Show(" ID not Present or Invalid ");

                con.Close();

            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Home\Documents\icon_college.mdf;Integrated Security=True;Connect Timeout=30");
            SqlCommand cmd = new SqlCommand("update students set firstname=@fname, lastname=@lname, departments=@department, gender=@gender, address=@address, phone=@phone, dob=@dob, email=@email where Id = @id ", con);

            
            cmd.Parameters.AddWithValue("@Id", txt_Id.Text);
            cmd.Parameters.AddWithValue("@fname", txt_firstname.Text);
            cmd.Parameters.AddWithValue("@lname", txt_lastname.Text);
            cmd.Parameters.AddWithValue("@department", txt_department.Text);
            cmd.Parameters.AddWithValue("@gender", txt_gender.Text);
            cmd.Parameters.AddWithValue("@address", txt_address.Text);
            cmd.Parameters.AddWithValue("@phone", txt_phone.Text);
            cmd.Parameters.AddWithValue("@dob", txt_dob.Text);
            cmd.Parameters.AddWithValue("@email", txt_email.Text);

            con.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show(" Record Updated Successfuly");
            con.Close();

            main_menu mm = new main_menu();
            this.Hide();
            mm.Show();

        }
    }
}
