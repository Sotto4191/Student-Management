﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management
{
    public partial class navigate_student : Form
    {
        int loc = 0;
        DataTable dt;

        public navigate_student()
        {
            InitializeComponent();
        }

        private void btn_quit_Click(object sender, EventArgs e)
        {
            main_menu mm = new main_menu();
            this.Hide();
            mm.Show();

        }

        private void navigate_student_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Home\Documents\icon_college.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "select * from students";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)

            {

                txt_firstname.Text = dt.Rows[0][1].ToString();
                txt_lastname.Text = dt.Rows[0][2].ToString();
                txt_department.Text = dt.Rows[0][3].ToString();
                txt_gender.Text = dt.Rows[0][4].ToString();
                txt_address.Text = dt.Rows[0][5].ToString();
                txt_phone.Text = dt.Rows[0][6].ToString();
                txt_dob.Text = dt.Rows[0][7].ToString();
                txt_email.Text = dt.Rows[0][8].ToString();
                txt_Id.Text = dt.Rows[0][0].ToString();

            }

            else
            {
                MessageBox.Show(" There is No record to be Retrieved from database");

                main_menu mm = new main_menu();
                this.Hide();
                mm.Show();


            }
        }

        private void btn_left_Click(object sender, EventArgs e)
        {

            if (loc < 1)
            {
                MessageBox.Show(" There is No record to be Retrieved to the Left");
            }



            else
            {
                loc--;

                txt_firstname.Text = dt.Rows[loc][1].ToString();
                txt_lastname.Text = dt.Rows[loc][2].ToString();
                txt_department.Text = dt.Rows[loc][3].ToString();
                txt_gender.Text = dt.Rows[loc][4].ToString();
                txt_address.Text = dt.Rows[loc][5].ToString();
                txt_phone.Text = dt.Rows[loc][6].ToString();
                txt_dob.Text = dt.Rows[loc][7].ToString();
                txt_email.Text = dt.Rows[loc][8].ToString();
                txt_Id.Text = dt.Rows[loc][0].ToString();
            }
        }

        private void btn_right_Click_1(object sender, EventArgs e)
        {

            if (loc >= dt.Rows.Count-1)
            {
                MessageBox.Show(" There is No record to be Retrieved to the Left");
            }



            else
            {
                loc++;

                txt_firstname.Text = dt.Rows[loc][1].ToString();
                txt_lastname.Text = dt.Rows[loc][2].ToString();
                txt_department.Text = dt.Rows[loc][3].ToString();
                txt_gender.Text = dt.Rows[loc][4].ToString();
                txt_address.Text = dt.Rows[loc][5].ToString();
                txt_phone.Text = dt.Rows[loc][6].ToString();
                txt_dob.Text = dt.Rows[loc][7].ToString();
                txt_email.Text = dt.Rows[loc][8].ToString();
                txt_Id.Text = dt.Rows[loc][0].ToString();
            }
        }
    }
}

  
