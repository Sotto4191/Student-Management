﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management
{
    public partial class discard_students : Form
    {
        public discard_students()
        {
            InitializeComponent();
        }

        private void discard_students_Load(object sender, EventArgs e)
        {
            groupbox1.Enabled = false;
            btn_erase.Enabled = false;

        }

        private void btn_quit_Click(object sender, EventArgs e)
        {
            main_menu mm = new main_menu();
            this.Hide();
            mm.Show();

        }

        private void btn_explore_Click(object sender, EventArgs e)
        {
            if (txt_Id.Text == "")
                MessageBox.Show("You are required yo enter an ID");

            else
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Home\Documents\icon_college.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "select * from students where Id = '" + txt_Id.Text + "' ";
                SqlDataAdapter sda = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
               
                {
                    btn_erase.Enabled = true;
                    txt_firstname.Text = dt.Rows[0][1].ToString();
                    txt_lastname.Text = dt.Rows[0][2].ToString();
                    txt_department.Text = dt.Rows[0][3].ToString();
                    txt_gender.Text = dt.Rows[0][4].ToString();
                    txt_address.Text = dt.Rows[0][5].ToString();
                    txt_phone.Text = dt.Rows[0][6].ToString();
                    txt_dob.Text = dt.Rows[0][7].ToString();
                    txt_email.Text = dt.Rows[0][8].ToString();

                }


                else
                    MessageBox.Show(" False  ID ");

                con.Close();


            }
        }

        private void btn_erase_Click(object sender, EventArgs e)
        {

            DialogResult dialogResult = MessageBox.Show("Are You Sure" , "Warning" , MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Home\Documents\icon_college.mdf;Integrated Security=True;Connect Timeout=30");
                String query = "delete from students where Id = '" + txt_Id.Text + "' ";
                SqlCommand cmd = new SqlCommand(query, con);
                con.Open();
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Successfuly Removed ");
                con.Close();
                main_menu mm = new main_menu();
                this.Hide();
                mm.Show();

            }

        }

        private void groupbox1_Enter(object sender, EventArgs e)
        {

        }

        private void txt_Id_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
