﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management
{
    public partial class main_menu : Form
    {
        public main_menu()
        {
            InitializeComponent();
        }

        private void btn_addstudentdetails_Click(object sender, EventArgs e)
        {
            add_student asf = new add_student();
            this.Hide();
            asf.Show();

        }

        private void btn_discardstudentdetails_Click(object sender, EventArgs e)
        {
            discard_students ds = new discard_students();
            this.Hide();
            ds.Show();

        }

        private void btn_explorestudentdetails_Click(object sender, EventArgs e)
        {
            navigate_student ns = new navigate_student();
            this.Hide();
            ns.Show();

        }

        private void btn_navigatestudentdetails_Click(object sender, EventArgs e)
        {
            explore_update nf = new explore_update();
            this.Hide();
            nf.Show();

        }
    }
}
