﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_management
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            String id = txt_id.Text;
            String password = txt_password.Text;
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Home\Documents\icon_college.mdf;Integrated Security=True;Connect Timeout=30");
            String query = "Select * from users where Id = '"+id+"' and password = '"+password+"' ";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Login Successful");
                main_menu mm = new main_menu();
                this.Hide();
                mm.Show();

            }
            else
                MessageBox.Show(" Invalid  Username or Password");

            con.Close();
        }
    }
}
